WITH observation_summary AS (
    SELECT
        person_id,
        MIN(observation_period_start_date) AS ehr_start_date,
        MAX(observation_period_end_date) AS ehr_end_date
    FROM `wb-silky-artichoke-2408.C2024Q3R9.observation_period`
    GROUP BY person_id
),

primary_consent AS (
    SELECT
        o.person_id,
        MIN(o.observation_date) AS index_date
    FROM `wb-silky-artichoke-2408.C2024Q3R9.concept` AS c
    INNER JOIN `wb-silky-artichoke-2408.C2024Q3R9.concept_ancestor` AS ca
        ON c.concept_id = ca.ancestor_concept_id
    INNER JOIN `wb-silky-artichoke-2408.C2024Q3R9.observation` AS o
        ON ca.descendant_concept_id = o.observation_concept_id
    WHERE c.concept_name = 'Consent PII'
      AND c.concept_class_id = 'Module'
    GROUP BY o.person_id
),

ehr_consent AS (
    SELECT
        person_id,
        MIN(observation_date) AS ehr_consent_date
    FROM `wb-silky-artichoke-2408.C2024Q3R9.observation`
    WHERE observation_source_concept_id = 1586099
      AND value_source_concept_id = 1586100
    GROUP BY person_id
),

candidate_a AS (
    SELECT
        p.person_id,
        pc.index_date
    FROM `wb-silky-artichoke-2408.C2024Q3R9.person` AS p
    INNER JOIN observation_summary AS os
        USING (person_id)
    INNER JOIN primary_consent AS pc
        USING (person_id)
    INNER JOIN ehr_consent AS ec
        USING (person_id)
    WHERE os.ehr_start_date <= pc.index_date
      AND os.ehr_end_date > pc.index_date
      AND (
            DATE_DIFF(
                os.ehr_start_date,
                DATE(
                    p.year_of_birth,
                    COALESCE(NULLIF(p.month_of_birth, 0), 7),
                    COALESCE(NULLIF(p.day_of_birth, 0), 1)
                ),
                DAY
            ) / 365.2425
          ) BETWEEN 18 AND 120
      AND (
            DATE_DIFF(
                pc.index_date,
                DATE(
                    p.year_of_birth,
                    COALESCE(NULLIF(p.month_of_birth, 0), 7),
                    COALESCE(NULLIF(p.day_of_birth, 0), 1)
                ),
                DAY
            ) / 365.2425
          ) BETWEEN 18 AND 120
),

recent_pregnancy AS (
    SELECT
        ca.person_id,
        MAX(
            CASE
                WHEN co.condition_start_date >= DATE_SUB(
                        ca.index_date,
                        INTERVAL 365 DAY
                     )
                 AND co.condition_start_date < ca.index_date
                 AND REGEXP_CONTAINS(
                        LOWER(COALESCE(c.concept_name, '')),
                        r'pregnan|postpartum|post-partum|puerper|gestation|delivery'
                     )
                THEN 1 ELSE 0
            END
        ) AS pregnancy_or_postpartum_recent_365d
    FROM candidate_a AS ca
    LEFT JOIN `wb-silky-artichoke-2408.C2024Q3R9.condition_occurrence` AS co
        ON ca.person_id = co.person_id
       AND co.condition_start_date < ca.index_date
    LEFT JOIN `wb-silky-artichoke-2408.C2024Q3R9.concept` AS c
        ON co.condition_concept_id = c.concept_id
    GROUP BY ca.person_id
)

SELECT *
FROM recent_pregnancy
