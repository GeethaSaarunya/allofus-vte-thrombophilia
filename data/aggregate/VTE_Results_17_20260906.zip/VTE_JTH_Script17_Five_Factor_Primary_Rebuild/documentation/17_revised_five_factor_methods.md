# Revised five-factor primary analysis methods

The revised primary clinical-risk burden is the unweighted count of five
pre-enrollment factors: cancer history, major surgery, inpatient hospitalization,
infection/sepsis, and fracture/major trauma. Pregnancy/postpartum is evaluated
separately because an all-history pre-enrollment EHR indicator does not
necessarily represent pregnancy or postpartum exposure proximal to the VTE-risk
period.

The five-factor burden is categorized as 0, 1, or >=2 factors for the clinically
readable comparison, while the exact 0-5 count is used as the clinical-burden
adjustment covariate in genetic models. Individual clinical factors are entered
together into one mutually adjusted logistic model. Both clinical models adjust
for age, recorded gender, 16 ancestry principal components, and EHR
observability and use HC0 robust standard errors.

Each of the seven targeted variants is evaluated in a separate model adjusted
for the exact five-factor burden, age, recorded gender, 16 ancestry principal
components, and EHR observability. The F5/F2 derived carrier indicator is a
supporting clinical-layering variable, not a third genetic variant.

Figure 3 reports observed, unadjusted VTE proportions within revised five-factor
burden categories. Formal interaction is tested separately using multiplicative
logistic interaction terms and adjusted probability-difference interaction via
marginal standardization.

The supporting prediction analysis compares five-fold out-of-fold predictions
from a clinical model containing age, recorded gender, 16 ancestry principal
components, the five individual clinical factors, and EHR observability with
the same model additionally containing separate F5 and F2 indicators.

The day-7 person-time analysis remains a post hoc sensitivity analysis. Clinical
burden interval-specific estimates should not be compared with genetic
interval-specific estimates as evidence of intrinsic biological risk stability,
because the genetic exposures are fixed while several clinical exposures are
transient and measured only before enrollment.
