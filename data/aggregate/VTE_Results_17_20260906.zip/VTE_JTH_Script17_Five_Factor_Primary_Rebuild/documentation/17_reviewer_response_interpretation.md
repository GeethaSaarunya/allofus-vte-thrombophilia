# Script 17 — reviewer-response interpretation

## Pregnancy/postpartum concern

The revised primary clinical-risk burden contains five factors: cancer history,
major surgery, inpatient hospitalization, infection/sepsis, and fracture/major
trauma. Pregnancy/postpartum is no longer counted in the accumulated burden
because an all-history pre-enrollment EHR indicator does not preserve the
time-limited nature of pregnancy-associated VTE risk.

The revised five-factor burden remained strongly graded:
- 1 factor vs 0: OR 2.01 (95% CI 1.87-2.16)
- >=2 factors vs 0: OR 3.74 (95% CI 3.50-3.99)

The all-history pregnancy/postpartum indicator had OR
0.88, whereas restricting pregnancy/postpartum
to the 365 days before enrollment yielded OR 1.03
(95% CI 0.85-1.24).
The inverse all-history estimate is therefore not interpreted as biological
protection.

The clinical-genetic layering result was preserved using the revised burden:
multiplicative interaction P=<0.001; adjusted
probability-difference interaction P=0.008.

## Prior VTE concern

The no-prior-VTE sensitivity should be reported with its actual five-factor
burden estimates rather than described only as directionally consistent:
- 1 factor vs 0: OR 1.69
- >=2 factors vs 0: OR 2.61
- either F5/F2: OR 1.77

Any attenuation relative to the primary model should be acknowledged as
evidence that recurrence or re-documentation of prior VTE may contribute to
the magnitude of the primary clinical-burden association.

## Temporal-stability concern

The interval-specific analysis should be described as a property of exposure
timing and study design. Genetic variants are fixed, while several clinical
components are transient pre-enrollment exposures. Do not contrast these as
evidence of greater biological "stability" of genetic risk.
